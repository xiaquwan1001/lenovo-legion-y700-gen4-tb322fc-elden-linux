# 相机主线移植（camss+S5KJNS/GC08A8 最小可跑）

评估并落地最小可跑相机通路：sensor 探测 + media graph 注册。交付 CAMERA-2026-10-02.md + config fragment + patch/boot。
