# Win x86 转译可行性(Steam)

见 .pi/missions/win-x86.md
