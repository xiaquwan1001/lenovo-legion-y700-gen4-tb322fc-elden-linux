# Win x86 转译 PoC(Box64+Wine)

见 .pi/missions/win-x86-poc.md
