# SMOKE2 worker liveness

跑 uname -a 并 task done
