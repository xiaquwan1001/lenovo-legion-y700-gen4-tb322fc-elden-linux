# 会话编目 batch3

读 /tmp/sess-audit/digests 摘要，产出 parts/batch3.jsonl
