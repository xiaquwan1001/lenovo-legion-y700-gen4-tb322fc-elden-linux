# 原厂相机+重力计驱动拆解

见 .pi/missions/stock-camgrav.md
