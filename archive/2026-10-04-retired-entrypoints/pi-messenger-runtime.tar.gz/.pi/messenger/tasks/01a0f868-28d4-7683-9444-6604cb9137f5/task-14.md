# 会话编目 batch1

读 /tmp/sess-audit/digests 摘要，产出 parts/batch1.jsonl
