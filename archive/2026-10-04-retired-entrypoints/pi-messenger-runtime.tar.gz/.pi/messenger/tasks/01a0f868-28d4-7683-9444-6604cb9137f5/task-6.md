# 音频出声: tplg 设备子图

见 .pi/missions/audio.md
