# CPU/GPU 多API性能基准

见 .pi/missions/bench.md
