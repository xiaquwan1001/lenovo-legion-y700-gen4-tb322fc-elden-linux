# Waydroid Google Play 认证+登录

见 .pi/missions/gplay.md
