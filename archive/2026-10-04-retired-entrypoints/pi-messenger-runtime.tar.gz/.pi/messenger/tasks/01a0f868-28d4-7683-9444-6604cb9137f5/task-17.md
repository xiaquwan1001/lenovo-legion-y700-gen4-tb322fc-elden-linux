# 会话编目 batch4

读 /tmp/sess-audit/digests 摘要，产出 parts/batch4.jsonl
