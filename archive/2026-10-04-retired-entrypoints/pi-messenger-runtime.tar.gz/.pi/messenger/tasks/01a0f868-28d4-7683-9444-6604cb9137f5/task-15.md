# 会话编目 batch2

读 /tmp/sess-audit/digests 摘要，产出 parts/batch2.jsonl
