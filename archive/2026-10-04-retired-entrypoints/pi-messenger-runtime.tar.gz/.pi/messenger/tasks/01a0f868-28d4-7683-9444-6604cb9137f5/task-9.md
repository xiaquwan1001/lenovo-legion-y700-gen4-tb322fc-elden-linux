# 相机主线移植(评估→最小可跑)

见 .pi/missions/camera.md
