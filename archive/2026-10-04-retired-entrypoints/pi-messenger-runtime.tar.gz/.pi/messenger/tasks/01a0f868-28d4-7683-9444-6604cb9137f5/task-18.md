# 会话编目 batch5

读 /tmp/sess-audit/digests 摘要，产出 parts/batch5.jsonl
