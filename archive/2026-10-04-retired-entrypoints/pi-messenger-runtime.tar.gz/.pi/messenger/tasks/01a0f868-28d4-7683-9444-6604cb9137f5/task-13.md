# SM8750 温控: trip重标定+GPU cooling+监控守护

见 .pi/missions/thermal.md。实测 CPU 热区曾达 103°C；passive trip=105°C 过高；需分级 trip、GPU cooling、thermal-watch.sh 监控。
