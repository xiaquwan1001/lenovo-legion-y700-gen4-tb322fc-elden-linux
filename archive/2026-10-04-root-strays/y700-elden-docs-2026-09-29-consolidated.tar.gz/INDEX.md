# 工作区索引 / 文档地图 — TB322FC "elden" mainline Linux

> **本文件是唯一入口。** 新会话先读这里，再按状态选读。
> 最后整理：2026-09-29（WiFi 开机全自动打通后）。

---

## 0. 一句话现状

主线 Linux 已在真机跑通：显示 / GPU(Adreno 830) / 触屏 / USB 网+SSH / 蓝牙 / ADSP /
**充电** / **WiFi(PEACH，开机全自动、有独立互联网)** / Wayland(weston)。
**启动已从 90s 优化到 ~5s。**

**未通**：音频出声（需自编 tplg）、GUI 桌面（Phosh 卡上游 glycin 沙箱 bug）、TF 卡
（`sdhci-msm` 驱动/卡问题）。

**当前基线镜像**：`out/boot-elden-vk10.img`
（`elden_root=LABEL=linux` → `/dev/sde79` 持久 root；含 WiFi 全自动脚本）。
**软回 fastboot / 跑主线**：`./cycle.sh --soft` / `fastboot boot out/boot-elden-vk10.img`。

---

## 1. 文档地图 ★

| 文件 | 状态 | 说明 |
|---|---|---|
| **`INDEX.md`**（本文件） | ✅ 当前 | 入口 / 状态 / 待办 |
| **`HANDOFF.md`** | ✅ 当前 | 技术总交接：设备/主机/构建/**根因**/产物/运维/UFS/持久 root/WiFi/GUI。**最新看 §21/§22** |
| **`PITFALLS.md`** | ✅ 当前 | ★ 踩坑总表（**动手前先扫一眼**） |
| **`BATCH_PLAN.md`** | ⚠️ 方法论仍有效，批次表已过时 | 减少物理重启的流程 |
| `restore-259/README.md` | ✅ 当前 | Android 免解 root / 回退 / EDL 救砖（独立于主线） |
| `backup/fw/README.md` | ✅ 当前 | 已采集固件资产来源说明 |
| `patches/README.md` | ✅ 当前 | 内核改动管理与迭代方式 |
| `复盘.md` | 🗄️ 历史档案 | 最早一轮操作史 + 2026-09-28 会话记录（已并入） |
| `out/archive/` | 🗄️ 历史产物 | 被 vk10 淘汰的调试镜像 |

图例：✅ 当前有效 ｜ ⚠️ 部分过时 ｜ 🗄️ 历史存档（仅追溯）。

> 已裁剪合并：`notes.md`→本文件+HANDOFF；`SESSION-2026-09-28.md`→`复盘.md`；
> `ROADMAP-drivers-gui.md`、`ATH12K-STABILITY.md`→本文件待办 + HANDOFF §22。

---

## 2. 设备 / 环境速查

| 项 | 值 |
|---|---|
| 机型 | 联想拯救者 Y700 四代 = **TB322FC** = `elden` = SM8750 |
| 屏 | LCD 1904×3040，双 DSI bonded+CPHY+DSC，Novatek **NT36536** |
| 序列号 | fastboot/adb `HA2ABH62`；主线 gadget SN `HA2CB1KY` |
| 主机 | `5700g-x8664`（Ubuntu 26.04），代理 `127.0.0.1:7897` |
| 设备地址 | USB-NCM `192.168.7.1`（主机 `enx…=192.168.7.2`）；WiFi DHCP 由热点分配 |
| 持久 root | `/dev/sde79`（2.3 GiB ext4，label `linux`） |
| 内核树 | `linux -> geekidos-linux`（GEEKiDoS/linux `v7.2-elden`，Linux 7.2.0） |

---

## 3. 快速入口命令

```bash
cd ~/y700-elden
# 跑主线（设备在 fastboot；dtbo 假镜像两槽）
fastboot flash dtbo_a out/dtbo-dummy.img; fastboot flash dtbo_b out/dtbo-dummy.img
fastboot boot out/boot-elden-vk10.img
# 访问
sudo bash elden-net.sh                    # 主机 enx…=192.168.7.2/24
ssh -o StrictHostKeyChecking=no root@192.168.7.1
# 软回 fastboot（不需按电源键）
./cycle.sh --soft
# 回 Android（先切槽，非破坏）
fastboot --set-active=a && fastboot reboot
# 内核增量编译（★ 绝不跑 olddefconfig —— 会删 CONFIG_ARCH_QCOM）
cd linux && make -j16 Image.gz dtbs
```

**WiFi（已在开机脚本里）**：`ath12k-retry.sh`（bind 未绑定设备）+ `net-up.sh`（wpa_supplicant+DHCP），
配置在 `/etc/wpa_supplicant/wpa_supplicant.conf`（当前 `vivo X200 Ultra` 热点）。
来源见 `scripts/`。

---

## 4. 待办看板

| 优先级 | 事项 | 参考 |
|---|---|---|
| ★★ | **GUI 桌面**：Phosh 已装、`phoc` 跑通，卡在 **glycin/gdk-pixbuf bwrap 沙箱 bug**（GNOME #196）。绕过：PNG 图标 / 打 glycin 补丁 / 换 Plasma Mobile（需先扩空间） | HANDOFF §22.4 |
| ★★ | **扩/缩分区**：给 Linux 更大根分区（Plasma Mobile 需 ~1.6G，现余 ~1.2G） | — |
| ★ | **TF 卡**：`sdhci-msm` 文件系统级写丢失（降速无效）。需内核排查 DMA/一致性，或换好卡 | HANDOFF §22.3 |
| ★ | **音频出声**：自编 tplg（MI2S→aw88461） | HANDOFF §15 |
| ★ | **WiFi 长稳**：本轮的"神秘重启"实为**掉电**；如需当真·主网，按长 ping/吞吐压测 + pstore 取证 | HANDOFF §22.5 |
| ☆ | 蓝牙配对 / 165Hz / 触觉 | HANDOFF §9 |

---

## 5. 目录速查

| 路径 | 内容 |
|---|---|
| `linux -> geekidos-linux` | 可编译内核树 |
| `Y700-elden-linux/` | 上游参考仓库（作者 .config / project 脚本） |
| `rootfs/` | Alpine rootfs 构建树 + 固件 + Mesa |
| `scripts/` | 构建/打包脚本 + `ath12k-retry.sh`、`net-up.sh`、`patch-init-*.sh` |
| `initramfs/` | 最小 busybox initramfs |
| `tools/mkbootimg/` | AOSP mkbootimg |
| `out/` | 产物；当前基线 `boot-elden-vk10.img`；旧件在 `out/archive/` |
| `backup/` | 关键备份（dtbo_a、固件、GPU zap、Mesa 原版、GPT 快照、rawdump） |
| `probe/` | 环境采集结果 |
| `pkgs*` | USB 离线装包用的 aarch64 apk |
| `restore-259/` | Android 免解 root 重签包 + KSU + EDL 救砖 |
| `y700四代工具/` `twrp/` | Windows 刷机工具 / TWRP（不进主线流程） |

---

## 6. 两个上游资源的关系（原 `notes.md`）

- **GEEKiDoS/linux `v7.2-elden`**（本工作区主用）：完整、可编译、作者已真机 `fastboot boot` 验证。
  elden DT 绑 `novatek,nt36536` 面板 + `novatek,nt36536-ts` 触摸。
- **xiaobai-Lethe/Y700-elden-linux**：非完整树，含作者 `.config`、`project/*.sh`、Mesa sysroot deb、
  `patches/linux-working-tree.patch`、`experiments/165hz-mode-table.patch`。

**打包 boot.img**（header v2，`pack.sh`）关键 cmdline：
```
console=ttyGS0,115200 console=tty0 loglevel=8 ignore_loglevel printk.devkmsg=on \
panic=15 clk_ignore_unused pd_ignore_unused arm-smmu.disable_bypass=0 [elden_root=LABEL=linux]
```
- `clk_ignore_unused pd_ignore_unused`：保住 ABL 留下的显示流水线（**★ 见 PITFALLS §5 核心根因**）。
- `arm-smmu.disable_bypass=0`：ABL 让 MDP 走未匹配的 SMMU 流，默认策略会立刻打死显示。
- boot.img 必须 < ~96 MiB（`boot_a` 大小上限）。

**主机 apt 依赖**：`gcc-aarch64-linux-gnu flex bison libssl-dev libelf-dev libncurses-dev bc`。
