#!/bin/bash
# Build a fastboot-bootable boot.img (kernel + busybox initramfs + DTB) for
# the Lenovo TB322FC (SM8750, "elden").
#
# Boot it into RAM with:   fastboot boot out/boot-elden.img
# (zero writes). Adapt from xiaobai-Lethe/Y700-elden-linux project/build-boot.sh.
set -e
ROOT=${ROOT:-$HOME/y700-elden}
KDIR=$ROOT/linux
OUT=$ROOT/out
IRAM=$ROOT/initramfs
MKBOOTIMG=$ROOT/tools/mkbootimg/mkbootimg.py
ROOTFS=$OUT/initramfs-root
mkdir -p "$OUT"

KERNEL=$KDIR/arch/arm64/boot/Image.gz
DTB=$KDIR/arch/arm64/boot/dts/qcom/sm8750-lenovo-elden.dtb
for f in "$KERNEL" "$DTB" "$IRAM/busybox" "$IRAM/init" "$IRAM/usb-gadget"; do
	[ -e "$f" ] || { echo "missing: $f"; exit 1; }
done

# --- initramfs ---------------------------------------------------------
rm -rf "$ROOTFS"
mkdir -p "$ROOTFS"/{bin,dev,proc,sys,tmp,mnt,etc}
cp "$IRAM/busybox" "$ROOTFS/bin/busybox"
chmod 755 "$ROOTFS/bin/busybox"
sed 's/\r$//' "$IRAM/init" > "$ROOTFS/init"
chmod 755 "$ROOTFS/init"
sed 's/\r$//' "$IRAM/usb-gadget" > "$ROOTFS/bin/usb-gadget"
chmod 755 "$ROOTFS/bin/usb-gadget"
mknod -m 600 "$ROOTFS/dev/console" c 5 1 2>/dev/null || true

( cd "$ROOTFS" && find . -print0 | cpio --null -o -H newc --owner=0:0 2>/dev/null | gzip -9 ) > "$OUT/initramfs.cpio.gz"
echo "initramfs: $(du -h "$OUT/initramfs.cpio.gz" | cut -f1)"

# --- cmdline ------------------------------------------------------------
# ttyGS0 = USB serial gadget console (needs CONFIG_U_SERIAL_CONSOLE);
# tty0    = screen via simple-framebuffer once it is up.
# clk_ignore_unused/pd_ignore_unused: keep the display pipeline ABL left
#   running alive so simple-framebuffer keeps scanning out.
# arm-smmu.disable_bypass=0: ABL leaves MDP fetching the splash buffer through
#   unmatched SMMU streams; the default "fault on unmatched stream" policy
#   kills the display the moment arm-smmu probes.
CONSOLES="${CONSOLES:-console=ttyGS0,115200 console=tty0}"
CMDLINE="$CONSOLES loglevel=8 ignore_loglevel printk.devkmsg=on panic=15 clk_ignore_unused pd_ignore_unused arm-smmu.disable_bypass=0${CMDLINE_EXTRA:+ $CMDLINE_EXTRA}"

# Dummy dtbo: wrong magic makes ABL skip the overlay path and boot the single
# DTB embedded in boot.img as-is.
dd if=/dev/zero of="$OUT/dtbo-dummy.img" bs=4096 count=1 2>/dev/null

python3 "$MKBOOTIMG" \
	--header_version 2 \
	--os_version 15.0.0 --os_patch_level 2025-08 \
	--kernel "$KERNEL" \
	--ramdisk "$OUT/initramfs.cpio.gz" \
	--dtb "$DTB" \
	--cmdline "$CMDLINE" \
	--base 0x00000000 \
	--kernel_offset 0x00008000 \
	--ramdisk_offset 0x01000000 \
	--second_offset 0x00f00000 \
	--tags_offset 0x00000100 \
	--dtb_offset 0x01f00000 \
	--pagesize 4096 \
	-o "$OUT/boot-elden.img"

echo
ls -la "$OUT/boot-elden.img"
echo
echo "Next: adb reboot bootloader && fastboot boot $OUT/boot-elden.img"
