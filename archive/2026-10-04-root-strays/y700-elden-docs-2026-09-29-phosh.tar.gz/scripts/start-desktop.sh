#!/bin/sh
# start-desktop.sh — Phosh (Wayland) desktop on the TB322FC panel.
#
# Runs on the persistent (disk) root only; /init launches it when
# $on_initramfs = 0 (i.e. root is /dev/sde79). Installed at
# /usr/local/sbin/start-desktop.sh on the device (canonical copy: scripts/).
#
# Replaces the earlier weston loop. Phosh needs udev (libinput/phoc device
# enumeration) and seatd, so both are started here. The session is restarted
# in a loop so the panel recovers if the compositor dies.
set -u

mkdir -p /run/udev /run/phosh
chmod 700 /run/phosh

# udev: phoc's libinput backend only sees the touchscreen if udevd has run.
if ! pgrep -x udevd >/dev/null 2>&1; then
	/sbin/udevd --daemon 2>/dev/null
	sleep 1
	/sbin/udevadm trigger --action=add 2>/dev/null
	/sbin/udevadm settle --timeout=5 2>/dev/null
fi

# seatd: DRM/input seat for phoc (libseat).
pgrep -x seatd >/dev/null 2>&1 || seatd -g root >/run/seatd.log 2>&1 &

export XDG_RUNTIME_DIR=/run/phosh
export XDG_SESSION_TYPE=wayland
export XDG_CURRENT_DESKTOP=Phosh:GNOME
export XDG_SESSION_DESKTOP=phosh
export GDK_BACKEND=wayland
export MOZ_ENABLE_WAYLAND=1

while true; do
	: > /run/phosh.log
	/usr/bin/phosh-session >>/run/phosh.log 2>&1
	echo "[start-desktop] phosh-session exited, restarting in 2s ($(date))" >>/run/phosh.log
	sleep 2
done
