# 主线 Linux —— 驱动装配 + 图形化用户界面（本阶段路线图）

> ⚠️ **部分过时（2026-09-29，见 `INDEX.md`）**：
> - §0 表中「充电 ❌」→ **已确认正常**（只是 PC USB 口限流，见 HANDOFF §21.3）。
> - §0 表中「WiFi ❌卡在 BDF」→ **已打通**（缺的是 `qdss_trace_config.bin`，见 HANDOFF §21.1）。
> - §1 D1/D2 的诊断步骤已执行完，**不再是待办**。
> - §4「边充边用会掉电」/「持久 root 只有 2.3 GiB 塞不下 Plasma」→ **体积约束作废**：
>   计划缩小 Android 分区给 Linux 更大根分区。
> - **仍然有效**：§2 GUI 选型表、§3 执行顺序骨架、D3 音频方向。
> - 最新状态以 `HANDOFF.md` §20/§21 + `INDEX.md` 为准。

> 目标：把 Y700 四代/TB322FC 的主线 Linux 从"能启动/能 SSH"推进到**可日常使用的平板**。
> 前置：`out/boot-elden-vk7.img`（持久 root，`elden_root=LABEL=linux`）。

## 0. 现状（已通 / 未通）

| 子系统 | 状态 | 说明 |
|---|---|---|
| 显示 / fbcon / weston | ✅ | 面板 + DRM，weston 14 开机自启，1904×3040 XR24 |
| GPU | ✅ | Adreno 830，Mesa Turnip Vulkan + freedreno GLES（已装持久 root）|
| 触屏 | ✅ | novatek nt36536 |
| USB 串口 / NCM 网 / SSH | ✅ | `192.168.7.1`，`enx…=192.168.7.2` |
| 蓝牙 | ✅ 上电 | 固件加载 OK，**扫描/配对未验证** |
| ADSP | ✅ | `adsp.mdt` + `adsp.b*` |
| **充电 / 电源** | ✅ 已确认正常（2026-09-29） | 之前掉电只是 PC USB 口 SDP ~400mA 限流，非驱动问题 |
| **WiFi (PEACH/WCN7861)** | ✅ 已打通（2026-09-29） | 卡点其实是缺 `qdss_trace_config.bin`；**稳定性/联网可用性待查** |
| **音频出声** | ❌ | ADSP+功放+card0 都在，缺**自编 tplg**（MI2S→aw88461）|
| 触觉 / 165Hz | ❌ | 低优先 |

## 1. 驱动装配（按"对可用性影响"排序）

### D1. 充电 / 电源 ★最优先
- 意义：主线长任务（装桌面/浏览器几百 MB）会耗尽电池 → 必须先解决，否则一切 GUI 装配都会翻车。
- 主机侧已知：DT 有 `pmic_glink`（两个 usb-c-connector，power-role=dual）+ `qcom,battery-current-inverted`；
  `CONFIG_BATTERY_QCOM_BATTMGR=y`（built-in），`CONFIG_QCOM_PMIC_GLINK=y`，`CONFIG_TYPEC_MUX_FSA4480=m`、`CONFIG_TYPEC_QCOM_PMIC=m`。
- 上机诊断（SSH）：
  ```sh
  for f in /sys/class/power_supply/*/*; do echo -n "$f="; cat "$f" 2>/dev/null; done | grep -Ei "current|voltage|status|online|type|health"
  dmesg | grep -Ei "pmic_glink|battmgr|charger|ucsi|typec|pd_|smb"
  ```
- 判定：① 插墙充（PD）时 `status=Charging`/`current_now` 为正 → 说明只是 PC 口限流，主线充电其实 OK；
  ② 完全不给 → 才需要改 DT/config（PD 协商角色、charger 节点）。

### D2. WiFi (PEACH / WCN7861) ← 主机侧可离线做
- 固件链路已通（`m3.bin`=vendor `phy_ucode20.elf`、`amss.bin`=vendor `amss20.bin`、…），
  **唯一缺口是 `board-2.bin`（BDF）**：linux-firmware 的 generic 无 PEACH 条目。
- 资产：`backup/fw/modem/image/peach/bdwlan.e01…e41` + `bdwlan.elf`（vendor 原始 BDF）。
- 方案：用 **`ath12k-bdencoder`**（qca-swiss-army-knife）把合适的 `bdwlan.eXX` 打成
  `ath12k/PEACH/hw2.0/board-2.bin`（或直接放 API1 的 `board.bin`）。
- 需先确认设备实际请求的 `qmi-board-id`（dmesg 里那条 `failed to fetch board data for bus=pci,…qmi-chip-id=2,qmi-board-id=??`）。

### D3. 音频出声
- 需自编 `Lenovo-Y700-Gen4-tplg.bin`（AudioReach 图：MI2S → aw88461 ×2）。
- 参考 vendor `/etc/MM_audio_playback_capture_v2.0.cfg`。属独立课题，工作量最大。

### D4. 蓝牙配对（低）
- 固件已上电；补 DBus/BlueZ agent 后重试。

## 2. 图形化用户界面（GUI）

现状：**weston 14 已在持久 root 上开机自启**（DRM 后端 + seatd + weston-terminal）。
本阶段要"装配成可用界面"。Alpine latest-stable 可选（已核实存在）：

| 方案 | 包 | 特点 | 适合度 |
|---|---|---|---|
| **Phosh**（推荐）| `phosh 0.55` + `squeekboard`/`wvkbd` | 移动/平板 GNOME 壳，触屏锁屏/状态栏/应用网格 | ★★★ 最贴合平板 |
| Plasma Desktop | `plasma-desktop 6.6.6` | 完整 KDE，功能强但重、耗电 | ★★ |
| weston + 组件 | `weston` + `sfwbar`/`waybar` + `foot` + 文件管理器 | 轻，稳，但要多攒 | ★★ |
| Sway / Xfce | `sway 1.12` / `xfce4` | 键鼠友好，触屏一般 | ★ |

通用必装：`font-dejavu`（字体）、`foot` 或 `weston-terminal`（终端）、`chromium` 或 `firefox`
（浏览器）、`squeekboard`/`wvkbd`（虚拟键盘）。

装包基建（主机中继代理，设备侧）：
```sh
# 主机：
socat TCP-LISTEN:7898,fork,reuseaddr TCP:127.0.0.1:7897
# 设备：repositories 用 http:// 源（避 CA），再
export http_proxy=http://192.168.7.2:7898 https_proxy=http://192.168.7.2:7898
apk update && apk add <pkgs>
```

## 3. 执行顺序（建议）

1. **先在 Android 充满电**（主线不充电）。
2. `adb reboot bootloader` → `fastboot boot out/boot-elden-vk7.img`（用户执行）。
3. 上机后 **D1 充电诊断**（决定后续能否长任务）。
4. 主机离线：**D2 WiFi board-2.bin**（`ath12k-bdencoder`）→ 推回设备验证。
5. GUI：**Phosh**（或用户指定方案）装到持久 root。
6. D3 音频 tplg（独立攻关）。

## 4. 风险 / 注意事项
- 主线**边充边用会掉电**：GUI 大包安装前先解决 D1，或分批 + 从 Android 充满。
- 持久 root 在 `/dev/sde79`；改动即时生效、跨重启保留；**先 `sync` 且别写坏 init**。
- USB gadget 长时间大流量易挂（见 PITFALLS）→ 优先用 WiFi（D2 通了就不依赖 USB）。
