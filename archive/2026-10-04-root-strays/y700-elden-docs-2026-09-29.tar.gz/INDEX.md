# 工作区索引 / 文档地图（TB322FC "elden" mainline Linux）

> **本文件是唯一入口。** 新会话先读这里，再按状态选读。
> 最后整理：2026-09-29（配合"ath12k 稳定性专项调查"）。

---

## 0. 一句话现状

主线 Linux 已在真机跑通大部分功能（显示/GPU/触屏/USB 网+SSH/蓝牙/ADSP/**充电**/**WiFi**），
**唯一未决重点 = WiFi(ath12k PEACH) 的稳定性与"是否真的能工作（联网）"**；
音频出声、GUI 装配为后续。

**当前基线镜像**：`out/boot-elden-vk7.img`（`elden_root=LABEL=linux` → `/dev/sde79` 持久 root）。

---

## 1. 文档状态总表 ★

| 文件 | 状态 | 说明 |
|---|---|---|
| **`INDEX.md`**（本文件） | ✅ 当前 | 入口 / 地图 / 状态裁决 |
| **`HANDOFF.md`** | ✅ 当前（§8/§9/§17.2/§18.2 已标注过时） | 总交接；**最新结论看 §20/§21** |
| **`PITFALLS.md`** | ✅ 当前 | 踩坑总表；§24 已修正（qdss 行） |
| **`notes.md`** | ✅ 当前 | 精简速查 |
| **`ATH12K-STABILITY.md`** | ✅ 当前（新建） | WiFi 稳定性/可用性专项调查方案 |
| **`ROADMAP-drivers-gui.md`** | ⚠️ **部分过时** | D1 充电、D2 WiFi 已完成；体积约束作废，见文件头横幅 |
| **`BATCH_PLAN.md`** | ⚠️ **部分过时** | §2.3/§4/§12 已过时，见文件头横幅 |
| **`restore-259/README.md`** | ✅ 当前 | Android 免解 root / 回退 / EDL 救砖（独立于主线） |
| **`backup/fw/README.md`** | ✅ 当前 | 固件资产来源说明 |
| **`patches/README.md`** | ✅ 当前 | 内核改动/迭代方式 |
| **`SESSION-2026-09-28.md`** | 🗄️ 历史档案 | 2026-09-28 会话快照；结论已并入 HANDOFF，保留作操作史 |
| **`复盘.md`** | 🗄️ 历史档案 | 最早一轮操作史/失败记录（已并入 PITFALLS/HANDOFF） |
| **`out/archive/`** | 🗄️ 历史产物 | 被 `out/boot-elden-vk7.img` 淘汰的旧调试镜像 |

图例：✅ 当前有效 ｜ ⚠️ 部分过时（读前先看横幅）｜ 🗄️ 历史存档（仅追溯用）。

---

## 2. 目录速查

| 路径 | 内容 |
|---|---|
| `HANDOFF.md` | 总交接（设备/主机/构建/根因/产物/运维/UFS/持久 root/Android 恢复…） |
| `PITFALLS.md` | 踩坑总表（引导/内核/存储/固件/装包/桌面/Android） |
| `INDEX.md` | 本文件 |
| `ATH12K-STABILITY.md` | ★ 下一步：WiFi 稳定性/可用性调查 |
| `linux -> geekidos-linux` | 可编译内核树（GEEKiDoS/linux `v7.2-elden`，Linux 7.2.0） |
| `Y700-elden-linux/` | 上游参考仓库（作者 .config / project 脚本） |
| `rootfs/` | Alpine rootfs 构建树 + 固件 + Mesa |
| `scripts/` | `build-boot.sh` `build-kernel.sh` `configure-elden.sh` `ath12k-retry.sh` `patch-init-ath12k.sh` |
| `initramfs/` | 最小 busybox initramfs（串口/探针） |
| `tools/mkbootimg/` | AOSP mkbootimg |
| `out/` | 产物；当前基线 `boot-elden-vk7.img`；旧件在 `out/archive/` |
| `backup/` | 关键备份（dtbo_a、固件、GPU zap、Mesa 原版、GPT 快照、rawdump） |
| `probe/` | 环境采集结果 + ath12k 固件暂存 |
| `pkgs/` | USB 离线装包用的 aarch64 apk |
| `restore-259/` | Android 1.5.10.259 免解 root 重签包 + KSU + EDL 救砖 |
| `y700四代工具/` | Windows 刷机工具（不进主线流程） |
| `twrp/` | TWRP 镜像（sha 已校验） |

---

## 3. 快速入口命令

```bash
# 回主线（设备在 fastboot）
fastboot flash dtbo_a out/dtbo-dummy.img && fastboot flash dtbo_b out/dtbo-dummy.img
fastboot boot out/boot-elden-vk7.img
# 访问
sudo bash ~/y700-elden/elden-net.sh      # 主机 enx… = 192.168.7.2/24
ssh -o StrictHostKeyChecking=no root@192.168.7.1
# 软回 fastboot（不按电源键）
./cycle.sh --soft
# 回 Android（先切槽，非破坏）
fastboot --set-active=a && fastboot reboot
```

---

## 4. 待办看板

| 优先级 | 事项 | 文档 |
|---|---|---|
| ★★★ | **ath12k 稳定性 + 实际联网可用性** | `ATH12K-STABILITY.md` |
| ★★ | GUI 选型/装配（体积不再是约束：将缩 Android 分区） | `ROADMAP-drivers-gui.md §2`（部分过时） |
| ★★ | 扩/缩分区：给 Linux 更大根分区 | 待立项 |
| ★ | 音频出声（自编 tplg：MI2S→aw88461） | HANDOFF §15、PITFALLS §21-23 |
| ★ | 蓝牙配对 / 165Hz / 触觉 | HANDOFF §9 |
