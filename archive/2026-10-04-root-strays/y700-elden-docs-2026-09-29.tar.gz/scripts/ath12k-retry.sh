#!/bin/sh
# ath12k (WCN7861 "Peach") boot-time probe retry.
#
# Root cause: ath12k's PCI driver probes at ~1.9s, before the Peach WCN power
# sequencer has brought the chip up. MHI POWER_ON then times out (-110) and the
# PCI device is left *unbound* (probe failed). Re-binding the still-unbound
# device a bit later (race over) makes firmware load + BDF succeed.
#
# Safety: this only ever binds when the device is present and currently has NO
# driver (/sys/.../driver absent). It never unbinds, because unbind/remove of a
# live ath12k device has been observed to hang the kernel.
#
# FIRMWARE: /lib/firmware/ath12k/PEACH/hw2.0/ must contain amss.bin, m3.bin,
# aux_ucode.bin, tmel.bin, board-2.bin, regdb.bin AND qdss_trace_config.bin
# (the last is a PEACH-only requirement this kernel's driver enforces).

DEV=/sys/bus/pci/devices/0000:01:00.0
DRV=/sys/bus/pci/drivers/ath12k_wifi7_pci
PHY=/sys/class/ieee80211/phy0

log() { echo "ath12k-retry: $*"; }

for i in $(seq 1 72); do
	sleep 5

	[ -e "$PHY" ] && { log "phy0 present, nothing to do"; exit 0; }
	[ -e "$DEV" ] || continue
	# still being probed or already successfully bound -> leave it alone
	[ -e "$DEV/driver" ] && continue

	if echo "$DEV" > "$DRV/bind" 2>/dev/null; then
		log "bound $DEV (attempt $i)"
	else
		continue
	fi

	j=0
	while [ "$j" -lt 20 ]; do
		sleep 3
		[ -e "$PHY" ] && break
		j=$((j + 1))
	done
	[ -e "$PHY" ] && { log "phy0 up"; exit 0; }
	log "bind did not produce phy0 (attempt $i)"
done

log "gave up after retries"
exit 1
