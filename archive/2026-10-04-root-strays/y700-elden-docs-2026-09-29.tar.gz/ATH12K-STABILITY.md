# ath12k (PEACH/WCN7861) 稳定性 & 可用性专项调查

> 目标：把「WiFi 打通了」推进到**「确实能用、且可信赖」**，或者拿到确凿证据说明它不行。
> 背景：HANDOFF §21 / PITFALLS §42-44。**当前基线 `out/boot-elden-vk7.img`**。
> 建立：2026-09-29。

---

## 0. 要回答的两个问题

| # | 问题 | 判定标准 |
|---|---|---|
| **Q1 是否工作** | 能否关联 AP、拿到 IP、跑通流量、DNS、HTTP？ | `iperf3`/`ping`/`curl` 成功并有吞吐数字 |
| **Q2 是否稳定** | 长时间/压力下会不会挂？挂的是不是 ath12k？ | 无 panic，或 panic 归因明确 |

**⚠️ 前提认知**：此前的"内核挂掉→重启"**并未定论**——可能只是物理重启、显示 vblank bug、USB gadget、过热等。
所以第一步**不是**假设驱动有问题，而是**先把崩溃观测能力做出来**。

---

## 1. 观测能力（先做，否则白测）

### 1.1 ramoops / pstore —— 崩溃现场★

内核已具备：
- `.config`：`CONFIG_PSTORE=y`、`CONFIG_PSTORE_RAM=y`、`CONFIG_PSTORE_CONSOLE=y`、`CONFIG_PSTORE_PMSG=y`、`CONFIG_PANIC_ON_OOPS=y`、`CONFIG_PANIC_TIMEOUT=10`。
- DT：`ramoops@c2000000`，`reg=<0 0xc2000000 0 0x400000>`，`console-size=0x200000`、`pmsg-size=0x200000`、`no-map`。
- **oops 也会 panic**（`PANIC_ON_OOPS`）→ 所有内核错误都会留下现场。

**每次上机第一件事**（在 WiFi 之前）：
```sh
ls -l /sys/fs/pstore/            # 有无内容 —— 有就是上一次启动崩过！
cat /sys/fs/pstore/console-ramoops-0     # panic 时的完整串口输出（尾部即 faulting stack）
cat /sys/fs/pstore/dmesg-ramoops-0
```
> **极重要**：如果现在设备是在某次"神秘重启"之后，ramoops 里**很可能就躺着证据**。
> 先读它，再决定后续。读完保留副本：`cp -a /sys/fs/pstore /root/pstore-$(date +%s)`。

验证 ramoops 真的工作：`echo c > /proc/sysrq-trigger`（**会主动 panic，仅在你准备好时做一次**）→ 重启后应能在 pstore 看到。

### 1.2 持久日志（UFS 根，跨重启保留）
```sh
# 把内核日志持续写到持久 root：
dmesg -w > /var/log/kmsg-$(date +%s).log 2>&1 &
logger -t BOOT "intentional boot at $(date)"   # 标记"有意启动"，用于区分崩溃重启
```
（另：busybox `syslogd -O /var/log/messages` 亦可。装 `busybox` 已有。）

### 1.3 带外通道：串口
主机：`sudo chmod 666 /dev/ttyACM0; stty -F /dev/ttyACM0 115200 raw -echo; cat /dev/ttyACM0 | tee ~/y700-elden/logs/serial-$(date +%s).log`
> USB 一挂，SSH + 串口（都走 USB gadget）**一起没**。所以**不能只靠串口**看 panic —— pstore 才是主力。

### 1.4 重启原因取证
- ABL 日志：`logfs` = `/dev/sde68` 的 `UefiLog1.txt`（挂载后 `grep -i reset`）。
- `dmesg | grep -iE 'psci|thermal|watchdog|reset reason'`。
- QCOM WDT：`CONFIG_QCOM_WDT=y`，若 hang 会被 WDT 复位（此时 pstore 可能只有 watchdog bark）。

---

## 2. 调查阶段（建议顺序）

### P0 取证先行（不折腾 WiFi）
1. 上机 → **先读 `/sys/fs/pstore`**（§1.1），保存副本。
2. 记录本次启动时间、槽位（`fastboot getvar current-slot` 已读）。
3. 起持久日志（§1.2）+ 主机串口日志（§1.3）。

### P1 对照组：**不开 WiFi** 的基线稳定性
> 目的：把"WiFi"与"其他原因"分离。

- 临时禁用自动重试脚本，让 ath12k 保持未绑定：
  ```sh
  mv /usr/local/sbin/ath12k-retry.sh /usr/local/sbin/ath12k-retry.sh.disabled
  # 或本次启动直接 pkill -f ath12k-retry（若已在跑）
  ```
- 跑 **30–60 min**：持续 `ping 192.168.7.2`、桌面 weston 常驻、不做别的事。
- 观察：是否仍会挂？
  - **会挂** → 与 WiFi 无关（display vblank / USB gadget / 电源 / 热），转查那些。
  - **不挂** → WiFi 嫌疑成立，进 P2/P3。

### P2 WiFi 功能测试（回答 Q1）——「是否工作」
1. 恢复脚本并手动触发绑定（**只 bind，绝不 unbind**）：
   ```sh
   ls -l /sys/bus/pci/devices/0000:01:00.0/driver    # 应为空（未绑定）
   echo 0000:01:00.0 > /sys/bus/pci/drivers/ath12k_wifi7_pci/bind
   dmesg | tail -80                                  # 看 chip_id/fw_version/TME-L/AUX_UC/FW_INIT_DONE
   iw dev                                            # 期待 wlan0
   ```
2. 关联一个真实 AP（**需网络信息**）：
   - 备选：手机热点 `vivo x200ultra` / 密码 `88880000`（用户提供过）；或 ustcnet/eduroam（需账号密码）。
   ```sh
   cat >/etc/wpa_supplicant.conf <<'EOF'
   ctrl_interface=/var/run/wpa_supplicant
   network={
     ssid="vivo x200ultra"
     psk="88880000"
   }
   EOF
   wpa_supplicant -B -i wlan0 -c /etc/wpa_supplicant.conf
   udhcpc -i wlan0
   ip a show wlan0; ip route
   ping -c5 <网关>; ping -c5 223.5.5.5; ping -c3 www.baidu.com   # DNS 也验
   ```
3. 吞吐（若有 iperf3；没有则用 `wget` 一个大文件计时）。
   - 结果写入 §4 记录表：**关联时间 / IP / RTT / 吞吐 / 丢包**。
4. **失败也要分类记**：扫描不到？关联失败？DHCP 失败？通了但丢包？

### P3 稳定性/压力（回答 Q2）
> 在 P2 能通的前提下。
- 长 ping：`ping -i 1 223.5.5.5 | ts >> /var/log/wifi-ping.log`（跑 1h+）。
- 吞吐压：`iperf3 -c <host> -t 600 -P 4`（双向各一次）。
- 反复 `iw scan` / `wpa_cli reassociate` 循环（触发固件路径）。
- 全程：`dmesg -w | grep -iE 'ath12k|mhi|qmi|firmware|panic|watchdog|thermal'`。
- **一旦挂**：重启后先读 `/sys/fs/pstore`，拿到 faulting stack 再谈。

### P4 归因
| 现象 | 指向 | 下一步 |
|---|---|---|
| pstore 有 ath12k fw_assert / MHI / QMI 栈 | **驱动/固件** | 用 `CONFIG_ATH12K_COREDUMP`；换固件版本；报上游 |
| pstore 有 display/drm 栈 | 显示 vblank bug（HANDOFF §18.3） | 与 WiFi 无关，单独查 |
| 只有 watchdog bark、无 panic 栈 | hang（非 oops） | 缩小 hang 点；查 USB gadget / 调度 |
| 无 pstore、但 `reboot` 记录异常 | 过热/掉电/物理 | 查 thermal、电池、是否手按电源 |
| 完全无异常、长跑不挂 | **稳定** | 结案，WiFi 可当主网 |

---

## 3. 禁区 / 注意事项（血泪）

- 🚫 **绝不对在线的 ath12k 设备 `unbind` / `remove`** —— 已两次挂内核→重启。只对「未绑定」设备 `bind`。
- 🚫 不要 `rmmod ath12k`（built-in，`CONFIG_ATH12K=y`，也动不了）。
- ✅ 崩了先读 `/sys/fs/pstore`，**不要**急着重刷/换内核。
- ✅ 每次测试前 `logger -t BOOT "intentional"`，以区分"我主动重启"和"它自己崩"。
- ✅ 记录**绝对时间**（`date`），与主机日志对齐。
- ⚠️ 若用手机热点测：注意热点自身会休眠/限速，别把热点问题算到驱动头上。

---

## 4. 记录表（测试时填）

| 轮次 | 日期 | 是否启 WiFi | 时长 | 是否崩 | pstore 摘要 | 关联/吞吐 | 备注 |
|---|---|---|---|---|---|---|---|
| P1 对照 | | 否 | | | | — | |
| P2 功能 | | 是 | | | | | |
| P3 压力 | | 是 | | | | | |

---

## 5. 一次性准备清单（可离线做）

- [ ] 主机建 `~/y700-elden/logs/` 收集串口/SSH 日志。
- [ ] 设备侧确认 `iw` / `wpa_supplicant` / `wireless-regdb` 在（memory 记载已装）。
- [ ] 视需要离线抓 `iperf3`、`ts`、`busybox`、`util-linux`（USB 离线装包流程见 HANDOFF §21.4 / PITFALLS §46）。
- [ ] 准备好目标 AP 的 SSID/密码（**待用户提供**）。

---

## 6. 待用户确认

1. **用哪个 AP 测**：手机热点（`vivo x200ultra`/`88880000`）？还是 ustcnet/eduroam（需账号密码）？
2. 是否同意 **P1 对照组先跑**（临时关自动重试、不开 WiFi 观察基线）？这是分离"WiFi 之罪"的关键。
3. 若 P1 就崩 → 说明不是 WiFi，**先去查 display vblank / USB gadget**，你 OK 吗？
