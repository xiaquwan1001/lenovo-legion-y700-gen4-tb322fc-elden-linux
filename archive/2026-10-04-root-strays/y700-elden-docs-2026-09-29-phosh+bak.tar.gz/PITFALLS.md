# 踩坑总表（TB322FC / elden mainline Linux）

> 📇 **先看 `INDEX.md`**（文档地图 + 状态裁决）。
> **给下一个会话：先读本文件 + `HANDOFF.md`。** 这里全是花过代价换来的教训，按主题归类。
> 最后更新：2026-09-29。

---

## 一、引导 / fastboot / 重启交接

1. **A/B 槽会漂移**：进过 Android/TWRP/多次 `fastboot boot` 后，`current-slot` 可能 a↔b。
   假 dtbo 必须**两个槽都写**（`dtbo_a` 和 `dtbo_b`），否则卡 logo。
   排查：`fastboot getvar current-slot`。
   ★★ **Android 卡启动动画（动画还在动、机身发热、数据没坏）→ 十有八九只是漂到了「引导链不配套」的槽。**
   2026-09-29 实测：`current-slot=b` 卡动画，仅 `fastboot --set-active=a` + `fastboot reboot` 就完好进系统、数据无损。
   **所以「进不去 Android」第一步 = 切另一个槽试试，别急着重刷/清数据。** a/b 都试一遍。

2. **内核 `reboot` 后总落 fastboot，是 ABL 的正常回退**，不是故障：
   - ABL 对**当前 Android 槽**做 AVB 校验，`boot_b` 公钥不匹配 / `dtbo_b` hash 不匹配 → 无法启动 → 回退 **fastboot**。
   - 主线 reboot 走 **PSCI SYSTEM_RESET**，且**没有 `reboot-mode` DT 节点** → 不向 ABL 传启动原因。
   - **清空 `misc`(sda7) 里的 `bootonce-bootloader` 无效**（已验证）。
   - 可用交接 = `fastboot boot <img>`（RAM，跳过 AVB）。
   - ABL 日志在 `logfs`（`/dev/sde68` 的 `UefiLog1.txt`），能看到它识别假 dtbo：`Dtbo hdr magic mismatch ... D7B7AB1E`。
   - **AVB 公钥资源**：该产品线有公开现成资源（酷安提到），日后做 verified-boot / 双槽直启的候选。

3. **fastboot 不能跑批量脚本/连续命令**：这台机响应差、易卡。
   一律**拆成单条简单命令**（`fastboot flash dtbo_a ...` / `fastboot boot ...` 各自单独）。
   报 **`Write to device failed (No such file or directory)`** 时：先单条 `fastboot reboot bootloader`，等待，再单条 `fastboot boot`。
   （`cycle.sh` 已按此简化：`--soft`/`--dtbo`/`--recover`/`<img>`。）

4. **`fastboot boot` 失败后 bootloader 会进"脏"状态**（连续报 `Load Error`）；`fastboot reboot bootloader` 可清。
   `fastboot boot` 报 `Failed to load/authenticate boot image: Load Error` 时同理。

5. **不要指望 `kexec` 换内核**：`CONFIG_KEXEC=y`，`kexec -l`/`-s -l` 都能**装载成功**，
   但 **`kexec -e` 执行会黑屏挂死**（新内核未起、无 USB gadget，需物理重启）。arm64/Qualcomm 平台限制。

6. **boot.img 必须 ≤96 MiB**（`boot_a`=0x6000000）；超了 `fastboot boot` 会 `Bad Buffer Size`。

7. **USB gadget 重枚举有延迟**：设备已进 Linux 但主机可能十几秒内看不到 `enx`/`ttyACM0`，等一下即恢复；别急着判定死机。

8. **SSH 失效时的救急通道**：串口 `/dev/ttyACM0`（CDC-ACM，getty on `ttyGS0`，直接 root shell）：
   ```bash
   stty -F /dev/ttyACM0 115200 raw -echo
   { printf '\r'; sleep 0.5; printf '<cmd>\r'; } > /dev/ttyACM0 & timeout 5 cat /dev/ttyACM0
   ```

---

## 二、内核 / DTS / 构建

9. **`make olddefconfig` 会删掉 `CONFIG_ARCH_QCOM` 整行！** 改 `.config` 后**绝不**跑它。
   用 `scripts/config -e/-d` 后直接 `make`，并每次 `grep ^CONFIG_ARCH_QCOM= .config` 验证。
   （`build.sh` 已内置校验。）

10. **ABL 会拿 stock dtbo overlay 我们的内嵌 DTB** → 卡 logo。解决：向两个槽写**假 dtbo**（4KB 全零）。
    假 dtbo 生效的迹象：ABL 日志 `Dtbo hdr magic mismatch`。

11. **`reserved-memory` 节点名 `splash-region`（连字符）→ ABL 找不到 `splash_region` 就关显示**；必须下划线。

12. **`&mdss_dp0` 必须 disabled**：DP 是无 ADSP 就永远 defer 的 DRM component，
    会卡住 `msm_drm_bind` → 没有 card0 → 黑屏。

13. **`CONFIG_PHY_NXP_PTN3222=y`（eUSB2 repeater 要内置，不能是 `=m`）**，否则 M31 PHY 起不来、无 USB。

14. **`CONFIG_BACKLIGHT_AW99706=y`**，否则 panel `Failed to get backlight`。

15. **不要打作者的 Mesa chip-id 补丁**（`...44050000`→`...44050001`）：本机内核报 `0xE844050000`（patchid **00**），
    正好匹配 Mesa **原版** wildcard；打补丁反而 unsupported。

16. **显示间歇性坏**：偶见 `drm_crtc_wait_one_vblank` call trace 刷屏（DPU 等不到 vblank → 只有背光无文字）。
    疑似 DSI/panel vblank 中断丢失，冷启/重来可恢复；暂未定位。

---

## 三、存储 / 分区 / 持久化

17. **LUN4 尾部 `last_parti` 的 Type-UUID 是全零** → 内核 GPT 解析器**跳过**它，不生成 `/dev/sde79`。
    解决：`fdisk /dev/sde` → `t 79` → 类型 `Linux filesystem` → `w`。只改类型 GUID，不动数据。
    （gdisk/fdisk/内核对它的口径不一致，以内核为准。）

18. **LUN0 无空闲**（userdata 到盘尾）；要加分区必须缩 super/userdata（有数据风险）。
    **`super`(sda10) 可直接读**：解析前 8MiB 的 LP 元数据 → 各分区 extent `{offset,len}`（单位 **512B** 扇区）→
    `losetup -o <off> --sizelimit <len> /dev/loop0 /dev/sda10`。映射见 `probe/result/lp-map.txt`。

19. **tar 拷贝会保留主机 uid（1000）** → sshd 报 `/var/empty must be owned by root` 拒绝启动，
    症状是 **ping 通、SSH `connection refused`**。
    修复：拷贝用 `tar --owner=0 --group=0`（或 cpio `--owner=0:0`），或事后 `find / -xdev -uid 1000 -exec chown 0:0 {} +`；
    init 已内置 `chown 0:0 /var/empty` 防御。

20. **持久 root**：initramfs 的 `init` 检测 cmdline `elden_root=LABEL=linux` → 挂载 → `switch_root` 到磁盘 `/init`。
    用 `stat -f -c %T /` 区分 initramfs(rootfs/tmpfs) 与磁盘(ext4)，磁盘模式跳过 `/persist` 与 switch_root（防递归）。
    打包：`EXTRA_CMDLINE="elden_root=LABEL=linux" ./pack.sh <rootfs> <img>`。

---

## 四、固件 / 外设（反提取 vendor 资源）

21. **ADSP 固件命名必须是 `qcom/sm8750/adsp.mdt`（+ `adsp.bXX` + `adsp_dtb.*`）**，
    不是 `adsp.mbn`。命名错的症状：`remoteproc: Direct firmware load for adsp.mdt failed -2` → 音频 deferred。
    （修复后 `adsp is now up`，音频宏 probe。）

22. **功放 aw88461 的 ACF**：vendor 的 `firmware/aw882xx_acf.bin` **内容就是 aw88461 的 ACF**（含 "aw88461" 字样）。
    拷成 DT 要的 `awinic/y700-gen4-speakers.bin` 即可（否则 `amplifier profile load failed`）。

23. **音频出声还需设备 tplg** `qcom/sm8750/Lenovo-Y700-Gen4-tplg.bin`（mainline AudioReach 拓扑）。
    linux-firmware 的 `SM8750-MTP-tplg.bin` 能用但后端只有 WCD Codec-DMA、**没有 MI2S**，`speaker-test` 打不开（-EINVAL）。
    需自编（vendor `/etc/MM_audio_playback_capture_v2.0.cfg` 可参考）。

24. **WiFi = ath12k / PEACH（PCI 0x110e，不是 WCN7850/0x1107！）**，固件目录 `ath12k/PEACH/hw2.0/`。
    从 vendor `modem/image/peach/` 反提取的对应关系：
    | ath12k | vendor 文件 |
    |---|---|
    | `m3.bin` | **`phy_ucode20.elf`**（e_machine=0x03，与 linux m3 同类；换它后 MHI 进 mission、固件启动）|
    | `amss.bin` | `amss20.bin` |
    | `aux_ucode.bin` | `aux_ucode20.elf` |
    | `tmel.bin` | `image/tmel_peach_20.elf` |
    | `regdb.bin` | `peach/regdb.bin` |
    | `qdss_trace_config.bin` | `peach/qdss_trace_config_v2.cfg` ← ★**必放，否则不建网卡（见 §42）** |
    | `board.bin`（API1 raw BDF）| `bdwlan.elf` / `bdwlan.eXX` |
    注意：PEACH 是 `board_api1_only`，驱动**不用 board-2.bin**，直接加载 **`board.bin`**。
    **进度（★已更新 2026-09-29）**：固件链全通、`wlan0` 已建立可扫描；详见 §42-44。
    （旧结论“QDSS 一加就崩内核”已废弃——那是早期未配套固件时的现象。）

25. **触屏固件**：`novatek_ts_csot_3k_fw.bin`（vendor `firmware/`）。
26. **蓝牙**：`qca/brhbtfw20.tlv` + `brhbtnv20.bin` + `brhperifw20.tlv` + `qca/tmel_peach_20.elf`；
    顺序加载，成功标志 `QCA setup on UART is completed`。
27. **GPU zap 必须设备签名版**（vendor `gen80000_zap.mbn`），linux-firmware 版被 TZ 拒（-EINVAL）。

---

## 五、设备上装包 / 环境

28. **早前"瘦身"Mesa/LLVM 时手删了文件但 apk 数据库还在** → `apk add` 不恢复（认为已装）。
    修复：**`apk fix <pkg>`**（重装缺失文件），别用 `--reinstall`（Alpine apk 无此选项）。
    受影响的：`mesa-egl mesa-gles mesa-gbm mesa-dri-gallium llvm22-libs`。

29. **设备无外网**。让设备直连 apk：主机 `socat TCP-LISTEN:7898,fork,reuseaddr TCP:127.0.0.1:7897`（0.0.0.0:7898→本地 CN 代理），
    设备把 `/etc/apk/repositories` 改成 **http** 源（避开缺 CA 的 TLS 问题），再
    `export http_proxy=http://192.168.7.2:7898 https_proxy=...; apk update && apk add <pkg>`。

30. **`socat` 后台化时别 `pkill -f 'TCP-LISTEN:7898'`** —— 会匹配到自己的命令行把当前 shell 杀掉（现象：命令 exit 143 无输出）。

---

## 六、脚本 / 工具

31. **busybox tar 不支持 `--ignore-failed-read`**：probe.sh 里用它导致拷贝为空。用整目录 `tar czf`。
32. **主机编内核依赖**：`gcc-aarch64-linux-gnu flex bison libssl-dev libelf-dev libncurses-dev bc`。
33. **主机代理**：`http://127.0.0.1:7897`（env 已设）；GitHub 大文件易截断，走代理。
34. **`apk info -W <file>`** 可查文件属于哪个包；`apk fix` 重装。

---

## 七、Wayland / 桌面（weston）

35. **weston 14 的 drm-backend 不再接受 `--tty=1`**（VT 改由 libseat 管理）：
    报 `fatal: unhandled option: --tty=1`，**即使 DRM/输出/EGL 都已经初始化成功**——很迷惑。
    正确命令：`weston --backend=drm --idle-time=0`（配 `seatd -g root`）。
    （别信旧笔记里的 `--tty=1`，那是旧 weston 语法；`§17.1` 已改正。）

36. **`weston-screenshooter` 在无输入/无 shell 授权时返回 `Output capture error: unauthorized`**：
    weston 的 `weston_capture_v1` 需要 shell 授权，headless 下截图不通。
    要确认桌面是否真在显示，用 DRM debugfs（**权威**）：
    `cat /sys/kernel/debug/dri/0/state` → 看 `plane-0` 的 `allocated by = weston`、`crtc=crtc-0`、`format=XR24`、`size=1904x3040`。

37. **weston-terminal 需要真实字体**：只装 `fontconfig` 不够，必须装字体（`apk add font-dejavu`），
    否则 pango 无字形、终端一片空白。

38. **桌面自启**：磁盘 root 模式下（`on_initramfs=0`）`/init` 调用 `/usr/local/sbin/start-desktop.sh`
    取代 tty1 getty；RAM 模式仍保留 getty。
    **当前脚本拉起 Phosh**（`udevd` + `seatd` + `phosh-session` 循环；见 §十）。
    历史：早期是 weston（`/etc/xdg/weston/weston.ini`，`[core] require-input=false` 必须加，
    `--tty=1` 在 weston 14 已失效；旧脚本备份 `start-desktop.sh.weston.bak`）。

---

## 八、恢复 Android / 免解 BL root 资产（2026-09-29）

39. **1.5.10.259 免解 root 原理**：高版本固件改了分区签名；老法（改分区 + 旧签名）会**卡机**。
    社区重签包 = **改过的 `abl`（信任自签密钥）+ 自签 `vbmeta`/`vbmeta_system`**，让系统以为仍是原厂签名。
    → **abl 与 vbmeta 必须配套一起刷**，不能只刷一半。资产见 `restore-259/`。
    build 核对：三个 vbmeta 的 fingerprint 均 = `ZUXOS_1.5.10.259_260611_PRC`；分区描述符不带槽后缀。
    重签包里 `boot_a.img` 与官方 `boot.img` **sha256 相同**（没改 boot），真正改的是 `abl_a.img`。

40. **回 Android 两步走**：① 先 `fastboot --set-active=<另一槽>`（非破坏，见第 1 条）；
    ② 不行才按 `restore-259/README.md` 刷重签包（abl 有砖风险，需 qdl+`xbl_s_devprg_ns.melf` 兜底）。

41. **EDL 救砖链**：`fastboot oem edl` 或 `adb reboot edl` → `~/y700-elden/qdl/build/qdl -s ufs restore-259/xbl_s_devprg_ns.melf read/write <分区> <文件>`。
    原厂固件目录 `~/下载/tb322fc/`（**不含 dtbo/vendor_boot/recovery/super**，不能全量恢复，只能逐分区）。

### 八之二、Android 应用数据备份 / 解密（2026-09-29）

用 **adb 从运行中的 Android** 导出 `Android/data/<pkg>` 即得**明文**（FBE 已透明解密）；
**不要**用 raw 分区 dump（那是 FBE 密文）。

- 本机 Android 16 的 `adb shell` 属于 `ext_data_rw` 组，**无需 root 就能读** `Android/data`：
  `adb exec-out 'tar -C /sdcard/Android/data -cf - <pkg> 2>/tmp/err' > pkg.tar`
  （只有 `-rw-------` 的 `tombstone_*` 崩溃转储读不到）。
- **Hollow Knight**（`com.TeamCherry.HollowKnight`）：存档 = `<25B 头>+base64(AES-256-ECB(json))+0x0b`，
  密钥公开 `UKu52ePUBwetZ9wNX88o54dnfKRu0T1l`。工具 `scripts/hk-save-decrypt.py`，已验证**逐字节可逆**。
- **Limbus Company**（`com.ProjectMoon.LimbusCompany`）：本地 `save_slot_*.json` = BOM+base64(AES 密文)，
  密钥未公开、无社区解密器；但**存档在服务器**，本地只是缓存，备份价值在 17 GB 素材。
- 备份产物在 `~/android-backup/`（含 README / sha256 / decrypted）。

---

## 九、WiFi / ath12k / 装包（2026-09-29）

42. **WiFi(PEACH) 缺的不是 board-2.bin，而是 `qdss_trace_config.bin`**：本机 PEACH 定制 ath12k 在 TME-L 后
    强制下载 QDSS trace 配置，缺文件就 `qmi failed to download QDSS config: -2` 直接不建网卡。
    放 `vendor peach/qdss_trace_config_v2.cfg` → `/lib/firmware/ath12k/PEACH/hw2.0/qdss_trace_config.bin`。

43. **★禁区：在线 ath12k 设备绝不能 `remove`/`unbind`**：实测两次都把内核挂死→重启→fastboot。
    只能对「首探失败、已未绑定」的设备 `bind`。

44. **开机首探 MHI `-110` 是竞态**：ath12k 在 ~1.9s probe，WCN 未就绪→MHI 超时→设备留未绑定。
    用只 bind 不 unbind 的延迟重试脚本（`scripts/ath12k-retry.sh`，已挂 `/init`）解决。
    另有稳定性隐患：bind 成功后运行一段时间内核崩（待查）。

45. **主线能充电，不必改电源驱动**：`qcom-battmgr-bat STATUS=Charging`，“插着净掉电”只是 PC USB 口供电不足。

46. **USB 离线装包（推荐，避开设备侧代理超时）**：主机 qemu-aarch64 跑 rootfs 的 apk `fetch --recursive` →
    scp → 设备 `apk add --allow-untrusted --no-network`。
    ⚠️ 设备 `/etc/apk/world` 残留未装的包（如 epiphany）会让 `apk add` 去补整条依赖树→上百包，先摘掉。

47. **持久 root 只有 2.3 GiB**：Phosh(~900MB) 能装；Plasma Mobile(~1.6GB) 装不下。装大桌面前先看 `df /`。

---

## 十、桌面 / Phosh（2026-09-29）

48. **Phosh 锁屏默认要 PIN**：`sm.puri.phosh.lockscreen require-unlock` 默认 `true`；
    本镜像 `/etc/pam.d/` 几乎为空（只有 `polkit-1`），**任何 PIN/密码都不可能通过** → 卡死在锁屏。
    解法：schema override 把 `require-unlock=false`（滑一下直接解锁）。
    产物：`/usr/share/glib-2.0/schemas/99_elden.gschema.override`（改后 `glib-compile-schemas`）。
    ⚠️ 直接 `gsettings set` 会失败：`Cannot autolaunch D-Bus without X11 $DISPLAY`——
    ssh 里没有 session bus；要设就 `export DBUS_SESSION_BUS_ADDRESS=$(tr '\0' '\n' < /proc/<phosh-pid>/environ | sed -n 's/^DBUS_SESSION_BUS_ADDRESS=//p')`，
    **或者**干脆用 override 文件（会话无关、可持久）。

49. **gdk-pixbuf 2.44 全走 glycin，glycin 的 bwrap 沙箱会让 loader `exit 1` → GTK 断言 → phosh abort**。
    glycin 自检（`sandbox.rs check_bwrap_syscalls_blocked`）遇到 bwrap 返回 SIGSYS / stderr 含
    `Creating new namespace failed` 时**自动切 NotSandboxed**；因此给 `bwrap` 装个打印该串并 `exit 1` 的 shim 即可
    （`scripts/glycin-bwrap-shim.sh`；`/init` 开机自动装）。
    ⚠️ **bwrap 完全不存在反而被判为可用**，删 bubblewrap 无效；glycin 无「关沙箱」环境变量。

50. **apk 说已装 ≠ 文件在**：`mesa-gl` 在包库里是 installed，但 `/usr/lib/libGL.so.1` 实际缺失
    → `gnome-session-check-accelerated` 的 gl-helper abort（`Couldn't open libGL.so.1`）
    → 加速检查失败 → **shell 根本不启动**。
    诊断要用 `ls`/`ldd`，别只信 `apk list -I`。修复：从 `pkgs-phosh/mesa-gl-*.apk` `tar -xzf -C /` 补回。

51. **gnome-session 必需组件失败 → fail whale**：`org.gnome.SettingsDaemon.Power` 在无 UPower/logind 时
    `exit 1`、`respawning too quickly` → `Unrecoverable failure in required component`。
    解法：从 `/usr/share/gnome-session/sessions/phosh.session` 的 `RequiredComponents` 里删掉 `org.gnome.SettingsDaemon.Power`
    （原文件备份 `phosh.session.orig`）。

52. **★ `pkill -f <模式>` 会匹配到自己的 ssh 命令行**：远程执行的 `sh -c '... pkill -f gnome-session-failed ...'`
    里本身含该字符串 → pkill 杀死自己的 shell（甚至整个会话，导致 phoc/phosh 一起退出）。
    用 **`pkill -x <精确进程名>`**，或把脚本写成文件再跑，绝不在 `-f` 模式里包含自己命令行的文本。

53. **Phosh 会话起来后要的东西**：`udevd`（libinput 认触屏，否则 phoc 报无设备）、`seatd`（libseat 拿 DRM/输入 seat）、
    `XDG_RUNTIME_DIR` 指向专用目录。启动脚本见 `scripts/start-desktop.sh`。

54. **截图取证**：Phosh 内置截图可直接 D-Bus 调用（无需 grim/phosh-screenshot）：
    `DBUS_SESSION_BUS_ADDRESS=... gdbus call --session --dest org.gnome.Shell.Screenshot --object-path /org/gnome/Shell/Screenshot --method org.gnome.Shell.Screenshot.Screenshot false false /tmp/x.png`。
    比看 DRM plane 更直观。
