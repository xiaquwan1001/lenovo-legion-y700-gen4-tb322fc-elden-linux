# 减少物理重启的工作规划（BATCH_PLAN）

> 目标：把"必须按电源键/物理干预"的次数压到最低。日期：2026-09-28。

## 1. 成本分层

| 类别 | 例子 | 代价 |
|---|---|---|
| A 主机离线 | 编内核、改 DTS/config、打 rootfs、解析固件元数据 | 0 |
| B 系统内 SSH（同一 boot 内） | 挂 UFS 分区、拉固件、测驱动/固件、Vulkan/GL、dm/losetup | 低，可无限次 |
| C 换内核/config/ABL | 新 Image、新 dtbo、新 cmdline | 高（一次 boot） |

## 2. 三个"软化开关"（已实测）

1. **kexec：装载可用，执行不可用** ⚠️（本轮实测）
   - `kexec -s -l`（file_load）→ `FILE_OK`；`kexec -l`（load）→ `LOAD_OK`（含 `--initrd`）。
   - **`kexec -e` 会黑屏挂死**（新内核未起、无 USB gadget），需物理重启。
   - 原因（推断）：arm64/Qualcomm 上跳到新内核后无法复位 GIC/PMIC/次级 CPU，属平台限制。
   - **结论：不能靠 kexec 做内核热切换。** 软重启路径改用 `reboot`（进 ABL→fastboot，无需按电源键；待实测）。
2. **UFS 全分区在 Linux 可见** ✅
   - 5 个 LUN（sda..sde）全部枚举；ext4/f2fs/vfat 直接挂载。
   - Android `super`（sda10）可用 LP 元数据 + `losetup -o` 定位动态分区（见 `probe/result/lp-map.txt`）→ vendor/vendor_dlkm 可读。
3. **持久 root 到 UFS**（未做，最高杠杆）
   - 把 Alpine/完整 Mesa 写成 ext4 到 `sda16`(userdata)/新分区，cmdline `root=`。
   - 做了它，用户态迭代脱离 RAM 96MiB 限制，也脱离重启。

## 3. 每次物理介入的模板

离线备齐该包全部产物；上机后脚本一次跑完，结果落 UFS + SSH 回传；尾部优先 kexec 换内核，否则 `reboot bootloader` 由主机 `fastboot boot` 接下一包。

```
□ 固件/DT/config 采集（B，一次拿全）
□ 多组内核/驱动实验合并进一个 Image（C 内并行）
□ 结果写 UFS + SSH 取回
□ 结束：kexec 换内核 → 否则 reboot bootloader 链式 fastboot boot
```

## 4. 批次队列

| 批次 | 内容 | 状态 |
|---|---|---|
| B0/B1 | 采集固件/DT/config + kexec 探针 | ✅ 完成（一次 boot） |
| B2 | 持久 root 到 UFS（Alpine+完整 Mesa） | 待办 |
| B3 | kexec `-e` 端到端内核热切换 | 待办 |
| B4 | WiFi/音频/触屏/165Hz 合版验证 | 待办（资产已齐） |

## 5. 本轮（B1）实测结论

- kexec 双系统调用 OK；无 `/sys/kernel/reboot-mode`（软回 fastboot 需另设）。
- 全部固件已离线/在线采集完成，见 `backup/fw/` + `probe/result/`。

## 8. 持久盘已就位（2026-09-28）

- `/dev/sde79` = 2.3 GiB ext4（LUN4 尾部原 `last_parti` 占位，类型全零内核跳过 → fdisk 改类型即用）。
- 零 GPT 手术、零数据丢失；重启后节点自动出现、数据保留。
- 可作 `/persist` 或持久 root。若需 >2.3 GiB 再考虑缩 super/userdata。

## 9. /persist 已上线（2026-09-28）

- `boot-elden-vk4.img` 的 init 在启动时自动 `mount /dev/sde79 /persist`（rw,noatime）。
- 实测：开机自动挂载成功，跨重启写入保留（`/persist/bootlog.txt`）。
- 用途：持久工作目录、工具链、构建缓存、固件/配置。

## 10. 音频（2026-09-28）

- ADSP ✅、功放 ACF ✅（vendor `aw882xx_acf.bin`）、card0 ✅。
- 出声卡点：需自编 `Lenovo-Y700-Gen4-tplg.bin`（AudioReach 图，MI2S→aw88461）。独立课题。

## 11. 持久 root 已打通（2026-09-28）★

- `elden_root=LABEL=linux` → initramfs `switch_root` 到 `/dev/sde79`，系统完全跑在 UFS。
- 基线：`out/boot-elden-vk7.img`。
- 坑：tar 拷贝保留 uid → sshd 拒启（`/var/empty`）；用 `--owner=0:0` 或启动后 chown。
- 串口 `/dev/ttyACM0` 可作 SSH 失效时的救急通道。

## 12. 图形/桌面 ✅ 与 WiFi ⏳（2026-09-28 夜）

- GL/GLES（kmscube, Adreno 830）与 Wayland（weston DRM）均跑通，包已装到持久 root。
- WiFi(PEACH ath12k) 卡在缺 PEACH 专用固件（m3/firmware-2.bin）；generic m3 被拒。
- 设备可经主机代理直连 `apk add`（见 HANDOFF §17.3）。
