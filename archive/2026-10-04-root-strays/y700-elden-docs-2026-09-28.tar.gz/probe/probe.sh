#!/bin/sh
# B1 probe: harvest firmware/DT/config + inventory UFS partitions.
# Runs in-RAM on TB322FC mainline Alpine. Output: /root/probe-out
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
OUT=/root/probe-out
FW=$OUT/fw
mkdir -p "$OUT" "$FW" /mnt/probe
log(){ echo "[probe] $*"; }

log "start $(date -u +%FT%TZ)"
{
  echo "=== uname ==="; uname -a
  echo "=== cmdline ==="; cat /proc/cmdline
  echo "=== partitions ==="; cat /proc/partitions
  echo "=== block nodes ==="; ls -l /dev/sd* /dev/mmcblk* 2>/dev/null
  echo "=== blkid ==="; blkid -o full 2>/dev/null
  echo "=== free/mem ==="; free -m; cat /proc/meminfo | head -5
} > "$OUT/00-system.txt" 2>&1
log "system done"

# kernel config
if [ -r /proc/config.gz ]; then zcat /proc/config.gz > "$OUT/kernel.config" 2>/dev/null; fi

# live device tree
if command -v dtc >/dev/null 2>&1 && [ -d /sys/firmware/devicetree/base ]; then
  dtc -I fs -O dts /sys/firmware/devicetree/base > "$OUT/devicetree.dts" 2>"$OUT/devicetree.err" || true
fi

# dmesg
dmesg > "$OUT/dmesg.txt" 2>&1 || true

# ---- mount every partition, look for firmware ----
: > "$OUT/partitions.txt"
for dev in $(ls /dev/sd[a-z] 2>/dev/null); do
  for part in $(ls ${dev}[0-9]* 2>/dev/null); do
    name=$(basename "$part")
    fstype=$(blkid -o value -s TYPE "$part" 2>/dev/null)
    label=$(blkid -o value -s LABEL "$part" 2>/dev/null)
    echo "$name type=${fstype:-?} label=${label:-?}" >> "$OUT/partitions.txt"
    # try candidate fs
    for fs in "" vfat ext4 erofs f2fs squashfs; do
      if [ -z "$fs" ]; then opts=""; else opts="-t $fs"; fi
      if mount -o ro $opts "$part" /mnt/probe 2>/dev/null; then
        short=$(echo "$name-$fstype" | tr -c 'A-Za-z0-9._-' '_')
        log "mounted $name as ${fstype:-auto}"
        # inventory one level
        ls -la /mnt/probe > "$OUT/mnt-$short.ls" 2>&1
        # find firmware-ish files
        find /mnt/probe -maxdepth 4 \( -iname '*ath12k*' -o -iname '*wcn*' -o -iname 'adsp*' -o -iname 'cdsp*' \
          -o -iname '*gen80000*' -o -iname 'novatek*' -o -iname 'nvt*' -o -iname '*.mbn' -o -iname '*.mdt' \
          -o -iname 'board*.bin' -o -iname 'panel*.bin' \) 2>/dev/null > "$OUT/fwfound-$short.txt"
        mkdir -p "$FW/$short"
        # copy firmware trees if any hit
        if [ -s "$OUT/fwfound-$short.txt" ]; then
          ( cd /mnt/probe && tar cf - --ignore-failed-read $(sed "s#^/mnt/probe/##" "$OUT/fwfound-$short.txt" 2>/dev/null) 2>/dev/null ) \
            | ( cd "$FW/$short" && tar xf - 2>/dev/null ) || true
        fi
        # also copy build.prop if vendor-ish
        find /mnt/probe -maxdepth 3 -name build.prop 2>/dev/null | while read bp; do
          cp "$bp" "$FW/$short/$(echo $bp | tr / _)" 2>/dev/null
        done
        umount /mnt/probe 2>/dev/null || umount -l /mnt/probe 2>/dev/null
        break
      fi
    done
  done
done
log "partitions done"

# ---- detect Android super (dynamic partitions) on LUN0 ----
for dev in /dev/sda /dev/sdb /dev/sdc /dev/sdd; do
  [ -b "$dev" ] || continue
  if dd if="$dev" bs=4096 count=1 2>/dev/null | grep -qa LP_METADATA; then
    echo "$dev has LP_METADATA (dynamic super)" >> "$OUT/super.txt"
    dd if="$dev" bs=4096 count=1 of="$OUT/$(basename $dev)-lphdr.bin" 2>/dev/null
  fi
done

# ---- kexec capability ----
KIMG=/tmp/kexec-Image
if gzip -dc /boot/elden-Image.gz > "$KIMG" 2>/dev/null; then kimg_ok=1; else kimg_ok=0; fi
{
  echo "=== kexec tools ==="; kexec --version 2>&1
  echo "=== decompressed Image ==="; ls -l "$KIMG" 2>&1
  echo "kexec_load_disabled=$(cat /proc/sys/kernel/kexec_load_disabled 2>/dev/null)"
  if [ "$kimg_ok" = 1 ]; then
    echo "=== kexec_file syscall (kexec -s -l) ==="
    kexec -s -l "$KIMG" --dtb=/boot/elden.dtb --reuse-cmdline 2>&1 && echo "FILE_LOAD_OK" || echo "FILE_LOAD_FAIL"
    kexec -u 2>&1 || true
    echo "=== kexec_load syscall (kexec -l) ==="
    kexec -l "$KIMG" --dtb=/boot/elden.dtb --reuse-cmdline 2>&1 && echo "LOAD_OK" || echo "LOAD_FAIL"
    echo "=== loaded segments ==="; kexec -l "$KIMG" --dtb=/boot/elden.dtb --reuse-cmdline 2>&1 | head; ls /sys/kernel/kexec* 2>&1
    kexec -u 2>&1 || true
  fi
  echo "=== reboot modes ==="
  ls -l /sys/kernel/reboot* /sys/firmware/reboot* 2>&1
  cat /sys/kernel/reboot-mode/* 2>&1
} > "$OUT/kexec-reboot.txt" 2>&1

log "kexec probe done"

# tar results
( cd "$OUT" && tar czf /root/probe-out.tar.gz . )
log "packed /root/probe-out.tar.gz $(ls -l /root/probe-out.tar.gz | awk '{print $5}') bytes"
log "DONE"
