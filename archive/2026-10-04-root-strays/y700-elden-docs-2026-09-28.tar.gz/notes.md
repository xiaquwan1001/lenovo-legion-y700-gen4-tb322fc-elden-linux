# Y700 Gen4 (TB322FC / "elden") mainline Linux — 工作区

设备：联想拯救者 Y700 四代 = TB322FC = 代号 `elden` = SM8750（骁龙8至尊版 / 8 Elite）
屏幕：LCD 双 DSI bonded + CPHY + DSC，CSOT PP8807HB1-1，驱动 IC 为 Novatek NT36536。

## 快速入口（★ 先读这些）

| 文件 | 内容 |
|---|---|
| **`HANDOFF.md`** | 总交接：设备/环境/构建/根因/产物/运维/kexec/UFS/持久分区/音频 |
| **`PITFALLS.md`** | ★ 踩坑总表（引导/内核/存储/固件/环境/脚本）——**先读** |
| **`SESSION-2026-09-28.md`** | 最近一轮会话的详细成果记录（固件采集/持久盘/功能落地） |
| `BATCH_PLAN.md` | 减少物理重启的方法论 + 软切换链 + 批次队列 |
| `复盘.md` | 完整操作史 + 失败记录 |
| `backup/fw/README.md` | 已采集固件资产说明 |
| `patches/README.md` | 自主迭代：内核改动管理与三级迭代方式 |

**当前最强镜像：`out/boot-elden-vk7.img`（77 MiB，`elden_root=LABEL=linux` → 从 `/dev/sde79` 持久 root 启动）。**
**迭代一条命令：`./iterate.sh`**；软回 fastboot：`./cycle.sh --soft`。
**持久盘：`/dev/sde79`（2.3 GiB ext4）；现为持久 root（`elden_root=LABEL=linux`）。**
已跑通：显示(fbcon) / USB 网+SSH / **触屏** / **蓝牙** / **ADSP** / **GPU(Turnip Vulkan + freedreno GLES)** / **Wayland(weston DRM)** / UFS。未通：音频出声(需自编 tplg)、WiFi(需 PEACH ath12k 固件)。

## 目录结构

```
~/y700-elden/
├── geekidos-linux/     # 可编译内核树：GEEKiDoS/linux，分支 v7.2-elden（Linux 7.2.0）
├── linux -> geekidos-linux   # 脚本统一引用 linux/
├── Y700-elden-linux/   # xiaobai-Lethe 仓库（参考：.config / patches / project 脚本 / mesa）
├── initramfs/          # busybox(arm64 static) + init + probe-device.sh
├── tools/mkbootimg/    # AOSP system/tools/mkbootimg（python）
├── scripts/            # 适配后的配置/编译/打包脚本
└── out/                # 产物（Image.gz / dtb / initramfs.cpio.gz / boot-elden.img）
```

## 两个上游资源的关系

- **GEEKiDoS/linux `v7.2-elden`**（本工作区主用）：完整、可编译、作者已 `fastboot boot` 真机验证。
  elden DT 绑定 `novatek,nt36536` 面板 + `novatek,nt36536-ts` 触摸。
- **xiaobai-Lethe/Y700-elden-linux**：不是完整树（`linux/` 只有 36 个参考文件），但含
  - `linux/.config`（319KB，作者实际构建用的完整配置，对应其 NT36523 面板版本）
  - `project/*.sh`（构建流水线：build-kernel/boot、configure-elden、rootfs、mesa）
  - `project/rootfs/debs/`（Mesa 交叉编译用的 arm64 sysroot deb 包）
  - `patches/linux-working-tree.patch`、`experiments/165hz-mode-table.patch`

## 编译配方（来自上游脚本）

内核：
```bash
cd ~/y700-elden/linux
export ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu-
make -j$(nproc) Image.gz dtbs
```

打包 fastboot-bootable boot.img（header v2）：
```bash
bash scripts/build-boot.sh
# -> out/boot-elden.img
```

关键 cmdline（build-boot.sh 已内置）：
```
console=ttyGS0,115200 console=tty0 loglevel=8 ignore_loglevel printk.devkmsg=on \
panic=15 clk_ignore_unused pd_ignore_unused arm-smmu.disable_bypass=0
```
- `clk_ignore_unused pd_ignore_unused`：保住 ABL 留下的显示流水线，simple-framebuffer 才有画面
- `arm-smmu.disable_bypass=0`：ABL 让 MDP 走未匹配的 SMMU 流，默认策略会立刻打死显示

刷入（RAM，零写入）：
```bash
adb reboot bootloader
fastboot boot out/boot-elden.img
```

## 依赖（apt，需 sudo）

`make defconfig` 在 git 树上需要 flex/bison 重新生成 kconfig 词法器，因此即使只做配置也需要它们。

```bash
sudo apt update
sudo apt install -y gcc-aarch64-linux-gnu flex bison libssl-dev libelf-dev libncurses-dev bc
```

## 已知问题（上游 commit 信息）

- USB 挂起仍 EBUSY 中止（中止后显示/音频/相机/传感器可恢复）
- 蓝牙固件能加载/上电，但扫描配对未通过
- 165Hz 只亮背光并触发 DSI FIFO 报错风暴（120Hz 正常；切回需冷重启）
